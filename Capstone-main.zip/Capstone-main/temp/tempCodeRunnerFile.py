
def team():
     return render_template('team.html')